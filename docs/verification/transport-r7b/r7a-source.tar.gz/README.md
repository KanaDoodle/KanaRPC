# KanaRPC

上下文优先的实验 Go RPC 内核。R7A 从新目录重新实现普通调用、服务端流式调用、远端取消和有截止时间的 drain；当前使用显式 TCP 连接，不兼容旧版 wire protocol。

当前阶段重点是可解释的请求状态和资源归属。方法通过泛型辅助函数显式注册，所有处理器接收 `context.Context`；普通与流式调用使用同一协议生命周期；执行与缓冲有数量/帧大小边界；成功终态带随机回执并等待客户端协议 ACK。

```go
server, _ := kanarpc.NewServer(kanarpc.ServerConfig{})
err := kanarpc.RegisterUnary(server, "/math/add", func(ctx context.Context, in [2]int) (int, error) {
    return in[0] + in[1], ctx.Err()
})
// Check err, create a net.Listener, then server.Serve(listener).
// client, err := kanarpc.Dial(ctx, address, kanarpc.ClientConfig{})
// err = client.Call(ctx, "/math/add", [2]int{1, 2}, &sum)
```

Go 1.26.0 或更新版本。本地验证：

```sh
go test ./...
go test -race ./...
python3 scripts/verify-core.py --output /tmp/kanarpc-core-new-run
```

最后一条命令启动两个独立进程，在真实 loopback TCP 上验证普通调用、20 个流式 chunk、用户取消，并在已接纳的流执行中发 SIGTERM，检查后续 chunk、EOF、回执及资源归零。数据和定时器是 fixture，没有调用模型。输出目录必须不存在，二进制和日志归该验收目录所有。

当前没有自动重试、隐式降级或业务重放。调用失败不能据此推断服务端没有执行；ACK 证明协议终态标识被收到，不证明业务提交或应用消费。

原 `KanaRPC-Go` 保留为衍生学习项目及历史对照，不删除其来源说明。这里不是把旧目录改名；实现来源、依赖及声明边界见 [ORIGINS.md](ORIGINS.md)。当前核心只依赖标准库；嵌套的 `tools/lifecycle-compare` 模块为对照实验单独引用旧项目。

R7B 的安全传输/原生 QUIC/发现、R7C 的过载治理和 R7D 的 CampusTrace 迁移均未完成；旧版本的功能清单、294 项测试和 R6 性能结果不能算作新版验收。没有创建远端仓库、发布 SDK 或修改 CampusTrace 默认依赖。不是生产框架。

设计与后续步骤：[重写计划](docs/rewrite-plan.md)、[v2 协议](docs/protocol-v2.md)。实际验收与遗留风险：[R7A 报告](docs/verification/core-r7/report.md)。

许可沿用 AGPL-3.0，标准许可证正文在 [LICENSE](LICENSE)。依赖库和通用算法不属于本项目原创发明。
