module github.com/KanaDoodle/KanaRPC

go 1.26.0
