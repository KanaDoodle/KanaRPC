package kanarpc

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"math"
	"net"
	"sync"
	"time"

	"github.com/KanaDoodle/KanaRPC/internal/wire"
)

type UnaryHandler func(context.Context, json.RawMessage) (json.RawMessage, error)
type StreamHandler func(context.Context, json.RawMessage, *Sender) error
type method struct {
	streaming bool
	run       StreamHandler
}
type serverState uint8

const (
	fresh serverState = iota
	serving
	draining
	closed
)

type ServerStats struct {
	Connections, InFlight, Executing                                  int
	Admitted, Completed, Rejected, Canceled, Delivered, LostTerminals uint64
}

// Server owns a listener after Serve succeeds, every accepted connection,
// and every admitted handler. Handler registration freezes at Serve.
type Server struct {
	cfg         ServerConfig
	mu          sync.Mutex
	state       serverState
	listener    net.Listener
	accepting   bool
	changed     chan struct{}
	methods     map[string]method
	connections map[*serverConn]struct{}
	stats       ServerStats
}

func NewServer(cfg ServerConfig) (*Server, error) {
	cfg, err := normalizeServer(cfg)
	if err != nil {
		return nil, err
	}
	return &Server{cfg: cfg, changed: make(chan struct{}), methods: make(map[string]method), connections: make(map[*serverConn]struct{})}, nil
}
func (s *Server) notifyLocked()      { close(s.changed); s.changed = make(chan struct{}) }
func (s *Server) Stats() ServerStats { s.mu.Lock(); defer s.mu.Unlock(); return s.stats }
func (s *Server) Ready() bool        { s.mu.Lock(); defer s.mu.Unlock(); return s.state == serving }

func (s *Server) HandleUnary(path string, h UnaryHandler) error {
	if h == nil {
		return errors.New("kanarpc: nil handler")
	}
	return s.register(path, method{run: func(ctx context.Context, b json.RawMessage, out *Sender) error {
		response, err := h(ctx, b)
		if err != nil {
			return err
		}
		return out.Send(response)
	}})
}
func (s *Server) HandleStream(path string, h StreamHandler) error {
	if h == nil {
		return errors.New("kanarpc: nil handler")
	}
	return s.register(path, method{streaming: true, run: h})
}
func (s *Server) register(path string, h method) error {
	if !validMethod(path) {
		return errors.New("kanarpc: expected /service/method")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.state != fresh {
		return errors.New("kanarpc: registration is frozen")
	}
	if _, ok := s.methods[path]; ok {
		return errors.New("kanarpc: duplicate method")
	}
	s.methods[path] = h
	return nil
}

// Serve transfers listener ownership only if the server has not started or
// closed. It returns when acceptance stops; Drain/Wait cover admitted work.
func (s *Server) Serve(listener net.Listener) error {
	if listener == nil {
		return errors.New("kanarpc: nil listener")
	}
	s.mu.Lock()
	if s.state != fresh {
		s.mu.Unlock()
		return ErrClosed
	}
	s.state, s.listener, s.accepting = serving, listener, true
	s.notifyLocked()
	s.mu.Unlock()
	defer func() { s.mu.Lock(); s.accepting = false; s.notifyLocked(); s.mu.Unlock() }()
	for {
		conn, err := listener.Accept()
		if err != nil {
			s.mu.Lock()
			stopped := s.state != serving
			s.mu.Unlock()
			if stopped {
				return nil
			}
			s.Close()
			return err
		}
		s.mu.Lock()
		if s.state != serving || len(s.connections) >= s.cfg.MaxConnections {
			s.mu.Unlock()
			closeSocket(conn)
			continue
		}
		ctx, cancel := context.WithCancelCause(context.Background())
		peer := &serverConn{server: s, link: newLink(conn, s.cfg.IO), ctx: ctx, cancel: cancel, requests: make(map[uint64]*execution)}
		s.connections[peer] = struct{}{}
		s.stats.Connections++
		s.notifyLocked()
		s.mu.Unlock()
		go peer.readLoop()
	}
}

func (s *Server) Close() {
	s.mu.Lock()
	s.state = closed
	l := s.listener
	peers := make([]*serverConn, 0, len(s.connections))
	for p := range s.connections {
		peers = append(peers, p)
	}
	s.notifyLocked()
	s.mu.Unlock()
	if l != nil {
		_ = l.Close()
	}
	for _, p := range peers {
		p.close(ErrClosed)
	}
}

// Wait joins owned connection readers and handlers, including handlers that
// ignore cancellation. It never claims to forcibly terminate Go functions.
func (s *Server) Wait(ctx context.Context) error {
	for {
		s.mu.Lock()
		done := !s.accepting && s.stats.Connections == 0 && s.stats.InFlight == 0
		changed := s.changed
		s.mu.Unlock()
		if done {
			return nil
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-changed:
		}
	}
}

// Drain seals admission under the same lock used by admit. Successful normal
// results are kept alive through receipt ACK; the caller deadline bounds drain.
func (s *Server) Drain(ctx context.Context) error {
	s.mu.Lock()
	if s.state == fresh {
		s.state = closed
	}
	if s.state == serving {
		s.state = draining
	}
	l := s.listener
	s.notifyLocked()
	s.mu.Unlock()
	if l != nil {
		_ = l.Close()
	}
	for {
		s.mu.Lock()
		quiet := !s.accepting && s.stats.InFlight == 0
		changed := s.changed
		s.mu.Unlock()
		if quiet {
			break
		}
		select {
		case <-ctx.Done():
			s.Close()
			return ctx.Err()
		case <-changed:
		}
	}
	s.Close()
	if err := s.Wait(ctx); err != nil {
		return err
	}
	if s.Stats().LostTerminals != 0 {
		return ErrDelivery
	}
	return nil
}

type serverConn struct {
	server   *Server
	link     *link
	ctx      context.Context
	cancel   context.CancelCauseFunc
	once     sync.Once
	mu       sync.Mutex
	requests map[uint64]*execution
	lastOpen uint64
}

func (p *serverConn) close(err error) {
	p.once.Do(func() { p.cancel(err); closeSocket(p.link.conn) })
}
func (p *serverConn) readLoop() {
	defer func() {
		p.close(ErrClosed)
		s := p.server
		s.mu.Lock()
		delete(s.connections, p)
		s.stats.Connections--
		s.notifyLocked()
		s.mu.Unlock()
	}()
	for {
		f, err := p.link.read()
		if err != nil {
			return
		}
		if f.Kind == wire.Open {
			if f.ID <= p.lastOpen {
				return
			}
			p.lastOpen = f.ID
			if err := p.open(f); err != nil {
				return
			}
			continue
		}
		if f.ID > p.lastOpen {
			return
		}
		p.mu.Lock()
		r := p.requests[f.ID]
		p.mu.Unlock()
		switch f.Kind {
		case wire.Cancel:
			if r != nil {
				r.cancel(context.Canceled)
			}
		case wire.Credit:
			if r != nil && !r.credit() {
				return
			}
		case wire.Ack:
			if r != nil && !r.acknowledge(f.Payload) {
				return
			}
		default:
			return
		}
	}
}

func (p *serverConn) reject(id uint64, code Code) error {
	s := p.server
	s.mu.Lock()
	s.stats.Rejected++
	s.mu.Unlock()
	b, _ := json.Marshal(endRecord{Status: Status{Code: code}})
	ctx, cancel := context.WithTimeout(p.ctx, s.cfg.IO.WriteTimeout)
	defer cancel()
	_, err := p.link.send(ctx, wire.Frame{Kind: wire.End, ID: id, Payload: b})
	return err
}
func (p *serverConn) open(f wire.Frame) error {
	var request openRecord
	if json.Unmarshal(f.Payload, &request) != nil || !validMethod(request.Method) || request.BudgetNanos <= 0 || request.Window < 1 || request.Window > 32 || !json.Valid(request.Request) {
		return p.reject(f.ID, InvalidArgument)
	}
	if !request.Stream && request.Window != 1 {
		return p.reject(f.ID, InvalidArgument)
	}
	s := p.server
	s.mu.Lock()
	if s.state != serving {
		s.mu.Unlock()
		return p.reject(f.ID, Unavailable)
	}
	h, ok := s.methods[request.Method]
	if !ok {
		s.mu.Unlock()
		return p.reject(f.ID, NotFound)
	}
	if h.streaming != request.Stream {
		s.mu.Unlock()
		return p.reject(f.ID, InvalidArgument)
	}
	p.mu.Lock()
	if s.stats.InFlight >= s.cfg.MaxInFlight || len(p.requests) >= s.cfg.MaxPerConnection {
		p.mu.Unlock()
		s.mu.Unlock()
		return p.reject(f.ID, ResourceExhausted)
	}
	duration := time.Duration(request.BudgetNanos)
	if duration > s.cfg.MaxRequestDuration {
		duration = s.cfg.MaxRequestDuration
	}
	budget, stop := context.WithTimeout(p.ctx, duration)
	ctx, cancel := context.WithCancelCause(budget)
	r := &execution{peer: p, id: f.ID, ctx: ctx, cancel: cancel, stop: stop, window: request.Window, credits: request.Window, changed: make(chan struct{}), ack: make(chan struct{})}
	p.requests[f.ID] = r
	s.stats.InFlight++
	s.stats.Executing++
	s.stats.Admitted++
	s.notifyLocked()
	p.mu.Unlock()
	s.mu.Unlock()
	go r.run(h, request.Request)
	return nil
}

type execution struct {
	peer                                *serverConn
	id                                  uint64
	ctx                                 context.Context
	cancel                              context.CancelCauseFunc
	stop                                context.CancelFunc
	sendMu                              sync.Mutex
	mu                                  sync.Mutex
	window, credits, sequence, returned uint32
	changed                             chan struct{}
	terminal                            bool
	receipt                             [16]byte
	ack                                 chan struct{}
	ackOnce                             sync.Once
}

// Sender is valid only during its handler invocation. Send is serialized and
// waits for receiver credits without blocking the connection's control reader.
type Sender struct{ request *execution }

func (out *Sender) Send(body json.RawMessage) error {
	r := out.request
	if !json.Valid(body) || uint64(len(body)) > uint64(r.peer.server.cfg.IO.MaxFrameBytes) {
		return &Status{Code: InvalidArgument, Message: "invalid or oversized JSON response"}
	}
	r.sendMu.Lock()
	defer r.sendMu.Unlock()
	for {
		if err := r.ctx.Err(); err != nil {
			return err
		}
		r.mu.Lock()
		if r.terminal {
			r.mu.Unlock()
			return ErrClosed
		}
		if r.credits > 0 {
			if r.sequence == math.MaxUint32 {
				r.mu.Unlock()
				return &Status{Code: ResourceExhausted, Message: "stream sequence exhausted"}
			}
			r.credits--
			r.sequence++
			number := r.sequence
			r.mu.Unlock()
			touched, err := r.peer.link.send(r.ctx, wire.Frame{Kind: wire.Data, ID: r.id, Number: number, Payload: body})
			if err != nil && touched {
				r.peer.close(err)
			}
			return err
		}
		changed := r.changed
		r.mu.Unlock()
		select {
		case <-r.ctx.Done():
			return r.ctx.Err()
		case <-changed:
		}
	}
}
func (r *execution) credit() bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.terminal {
		return true
	}
	if r.returned >= r.sequence || r.credits >= r.window {
		return false
	}
	r.returned++
	r.credits++
	close(r.changed)
	r.changed = make(chan struct{})
	return true
}
func (r *execution) acknowledge(receipt []byte) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	if !r.terminal || string(r.receipt[:]) != string(receipt) {
		return false
	}
	r.ackOnce.Do(func() { close(r.ack) })
	return true
}

func invoke(h method, ctx context.Context, b json.RawMessage, out *Sender) (err error) {
	defer func() {
		if recover() != nil {
			err = &Status{Code: Internal, Message: "handler panicked"}
		}
	}()
	return h.run(ctx, b, out)
}
func (r *execution) run(h method, body json.RawMessage) {
	s := r.peer.server
	defer func() {
		r.cancel(ErrClosed)
		r.stop()
		// Admission takes server then peer; cleanup follows the same lock order.
		s.mu.Lock()
		r.peer.mu.Lock()
		delete(r.peer.requests, r.id)
		r.peer.mu.Unlock()
		s.stats.InFlight--
		s.stats.Completed++
		s.notifyLocked()
		s.mu.Unlock()
	}()
	err := invoke(h, r.ctx, body, &Sender{request: r})
	if r.ctx.Err() != nil {
		err = r.ctx.Err()
	}
	classified := statusOf(err)
	s.mu.Lock()
	s.stats.Executing--
	if classified.Code == Canceled || classified.Code == DeadlineExceeded {
		s.stats.Canceled++
	}
	s.notifyLocked()
	s.mu.Unlock()
	if r.ctx.Err() == context.Canceled || r.peer.ctx.Err() != nil {
		return
	}
	r.sendMu.Lock()
	defer r.sendMu.Unlock()
	r.mu.Lock()
	r.terminal = true
	status := endRecord{Status: classified}
	wantACK := r.ctx.Err() == nil
	if wantACK {
		if _, e := rand.Read(r.receipt[:]); e != nil {
			r.mu.Unlock()
			r.peer.close(e)
			return
		}
		status.Receipt = hex.EncodeToString(r.receipt[:])
	}
	r.mu.Unlock()
	b, _ := json.Marshal(status)
	ctx, cancel := context.WithTimeout(r.peer.ctx, s.cfg.AckTimeout)
	defer cancel()
	touched, writeErr := r.peer.link.send(ctx, wire.Frame{Kind: wire.End, ID: r.id, Payload: b})
	if writeErr != nil {
		if touched {
			r.peer.close(writeErr)
		}
		if wantACK {
			r.recordDelivery()
		}
		return
	}
	if !wantACK {
		return
	}
	select {
	case <-r.ack:
	case <-r.ctx.Done():
	case <-ctx.Done():
	}
	r.recordDelivery()
}

func (r *execution) recordDelivery() {
	s := r.peer.server
	s.mu.Lock()
	defer s.mu.Unlock()
	// ACK is an irreversible protocol observation. A later socket close or a
	// racing deadline must not overturn it, even if both select cases are ready.
	select {
	case <-r.ack:
		s.stats.Delivered++
	default:
		cause := context.Cause(r.ctx)
		if cause != context.Canceled && cause != context.DeadlineExceeded {
			s.stats.LostTerminals++
		}
	}
}

// RegisterUnary provides compile-time request/response types without reflection.
func RegisterUnary[Request, Response any](s *Server, path string, h func(context.Context, Request) (Response, error)) error {
	if h == nil {
		return errors.New("kanarpc: nil handler")
	}
	return s.HandleUnary(path, func(ctx context.Context, body json.RawMessage) (json.RawMessage, error) {
		var request Request
		if json.Unmarshal(body, &request) != nil {
			return nil, &Status{Code: InvalidArgument, Message: "request decode failed"}
		}
		response, err := h(ctx, request)
		if err != nil {
			return nil, err
		}
		b, err := json.Marshal(response)
		return b, err
	})
}
func RegisterStream[Request, Response any](s *Server, path string, h func(context.Context, Request, func(Response) error) error) error {
	if h == nil {
		return errors.New("kanarpc: nil handler")
	}
	return s.HandleStream(path, func(ctx context.Context, body json.RawMessage, out *Sender) error {
		var request Request
		if json.Unmarshal(body, &request) != nil {
			return &Status{Code: InvalidArgument, Message: "request decode failed"}
		}
		return h(ctx, request, func(response Response) error {
			b, err := json.Marshal(response)
			if err != nil {
				return fmt.Errorf("response encode: %w", err)
			}
			return out.Send(b)
		})
	})
}
