package kanarpc

import (
	"errors"
	"time"

	"github.com/KanaDoodle/KanaRPC/internal/wire"
)

type IOConfig struct {
	// MaxFrameBytes bounds an entire payload, including Open metadata.
	MaxFrameBytes uint32
	WriteTimeout  time.Duration
	// ReadTimeout bounds the time to read one complete record, including idle.
	ReadTimeout time.Duration
}
type ClientConfig struct {
	EnableCallOptions bool
	Compression       *CompressionConfig
	TCPKeepAlive      *TCPKeepAliveConfig
	// RequiredFeatures enables a bounded pre-dispatch handshake. Zero preserves
	// legacy JSON connections. Protobuf calls require FeatureProtobuf here.
	RequiredFeatures   Feature
	negotiatedFeatures Feature
	// MemoryAccount is an optional single-owner share of a MemoryPool.
	MemoryAccount  *MemoryAccount
	Feedback       *FeedbackConfig
	Memory         MemoryConfig
	IO             IOConfig
	Timeout        time.Duration
	MaxInFlight    int
	StreamWindow   int
	ControlTimeout time.Duration
}
type ServerConfig struct {
	Compression    *CompressionConfig
	TCPKeepAlive   *TCPKeepAliveConfig
	Interceptors   []Interceptor
	Authenticate   Authenticator
	RateLimiter    *RateLimiter
	Trace          *TraceRecorder // nil disables the bounded local decision journal
	Governance     *GovernanceConfig
	Memory         MemoryConfig
	IO             IOConfig
	MaxConnections int
	// MaxInFlight includes queued work, handlers and terminal-ACK/FIN waiters.
	MaxInFlight        int
	MaxPerConnection   int
	MaxRequestDuration time.Duration
	AckTimeout         time.Duration
}

func normalizeIO(c IOConfig) (IOConfig, error) {
	if c.MaxFrameBytes == 0 {
		c.MaxFrameBytes = 1 << 20
	}
	if c.WriteTimeout == 0 {
		c.WriteTimeout = time.Second
	}
	if c.ReadTimeout == 0 {
		c.ReadTimeout = 30 * time.Second
	}
	if c.MaxFrameBytes < 1024 || c.MaxFrameBytes > wire.HardLimit || c.WriteTimeout <= 0 || c.ReadTimeout <= 0 {
		return c, errors.New("kanarpc: invalid IO bounds")
	}
	return c, nil
}
func normalizeClient(c ClientConfig) (ClientConfig, error) {
	var err error
	if c.Compression, err = compressionConfig(c.Compression); err != nil {
		return c, err
	}
	if c.TCPKeepAlive, err = normalizeKeepAlive(c.TCPKeepAlive); err != nil {
		return c, err
	}
	if c.EnableCallOptions || c.Compression != nil {
		c.EnableCallOptions = true
		c.RequiredFeatures |= FeatureCallOptions
	}
	if c.RequiredFeatures & ^supportedFeatures != 0 {
		return c, errors.New("kanarpc: unknown required protocol features")
	}
	if c.Feedback, err = normalizeFeedback(c.Feedback); err != nil {
		return c, err
	}
	if c.IO, err = normalizeIO(c.IO); err != nil {
		return c, err
	}
	encodingMinimum := int64(c.IO.MaxFrameBytes) * 2
	if c.EnableCallOptions {
		encodingMinimum += 8192
	}
	if c.Compression != nil {
		encodingMinimum += compressionWriteWorkspace
	}
	if c.Memory.EncodingBytes == 0 && encodingMinimum > 16<<20 {
		c.Memory.EncodingBytes = encodingMinimum
	}
	if c.Memory, err = memoryConfig(c.Memory); err != nil {
		return c, err
	}
	if c.Memory.EncodingBytes < encodingMinimum {
		return c, errors.New("kanarpc: encoding capacity must include frames and configured codec workspace")
	}
	if c.Timeout == 0 {
		c.Timeout = 5 * time.Second
	}
	if c.MaxInFlight == 0 {
		c.MaxInFlight = 64
	}
	if c.StreamWindow == 0 {
		c.StreamWindow = 8
	}
	if c.ControlTimeout == 0 {
		c.ControlTimeout = 250 * time.Millisecond
	}
	if c.Timeout <= 0 || c.MaxInFlight < 1 || c.MaxInFlight > 4096 || c.StreamWindow < 1 || c.StreamWindow > 32 || c.ControlTimeout <= 0 {
		return c, errors.New("kanarpc: invalid client bounds")
	}
	if c.MemoryAccount != nil {
		if err := c.MemoryAccount.pool.CheckClient(c); err != nil {
			return c, err
		}
	}
	return c, nil
}
func normalizeServer(c ServerConfig) (ServerConfig, error) {
	var err error
	if c.Compression, err = compressionConfig(c.Compression); err != nil {
		return c, err
	}
	if c.TCPKeepAlive, err = normalizeKeepAlive(c.TCPKeepAlive); err != nil {
		return c, err
	}
	c.Interceptors = append([]Interceptor(nil), c.Interceptors...)
	if c.Memory, err = memoryConfig(c.Memory); err != nil {
		return c, err
	}
	if c.IO, err = normalizeIO(c.IO); err != nil {
		return c, err
	}
	if c.MaxConnections == 0 {
		c.MaxConnections = 64
	}
	if c.MaxInFlight == 0 {
		c.MaxInFlight = 128
	}
	if c.MaxPerConnection == 0 {
		c.MaxPerConnection = 32
	}
	if c.MaxRequestDuration == 0 {
		c.MaxRequestDuration = 30 * time.Second
	}
	if c.AckTimeout == 0 {
		c.AckTimeout = time.Second
	}
	if c.MaxConnections < 1 || c.MaxConnections > 4096 || c.MaxInFlight < 1 || c.MaxInFlight > 4096 || c.MaxPerConnection < 1 || c.MaxPerConnection > 4096 || c.MaxRequestDuration <= 0 || c.AckTimeout <= 0 {
		return c, errors.New("kanarpc: invalid server bounds")
	}
	if c.Governance, err = normalizeGovernance(c.Governance, c.MaxInFlight); err != nil {
		return c, err
	}
	return c, nil
}
