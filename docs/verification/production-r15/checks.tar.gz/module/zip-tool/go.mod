module example.com/module-packaging

go 1.26.10

require golang.org/x/mod v0.42.0
