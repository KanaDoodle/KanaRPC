package main
import("os";"fmt";"golang.org/x/mod/module";"golang.org/x/mod/zip")
func main(){f,e:=os.Create(os.Args[3]);if e!=nil{panic(e)};defer f.Close();if e=zip.CreateFromDir(f,module.Version{Path:"github.com/KanaDoodle/KanaRPC",Version:os.Args[2]},os.Args[1]);e!=nil{panic(e)};p,e:=module.EscapePath("github.com/KanaDoodle/KanaRPC");if e!=nil{panic(e)};fmt.Println(p)}
