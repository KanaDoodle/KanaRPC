package main
import _ "github.com/KanaDoodle/KanaRPC/observability"
