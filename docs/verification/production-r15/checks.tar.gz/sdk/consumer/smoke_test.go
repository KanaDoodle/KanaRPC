package consumer_test

import (
 "context"
 "errors"
 "fmt"
 "io"
 "net"
 "testing"
 "time"
 rpc "github.com/KanaDoodle/KanaRPC"
 "example.com/protobuf-consumer/pb"
 "google.golang.org/protobuf/proto"
 "google.golang.org/protobuf/types/known/wrapperspb"
)

type implementation struct { pb.UnimplementedEchoServer; canceled chan struct{} }
func (*implementation) Call(ctx context.Context, in *pb.Request) (*wrapperspb.StringValue,error) {
 if !in.HasText() { return nil, fmt.Errorf("missing explicit text presence") }
 return wrapperspb.String(in.GetText()), ctx.Err()
}
func (s *implementation) Watch(ctx context.Context, in *pb.Request, send func(*wrapperspb.StringValue) error) error {
 if in.GetCount()==0 {
  if err:=send(wrapperspb.String("ready")); err!=nil {return err}
  <-ctx.Done(); close(s.canceled); return ctx.Err()
 }
 for n:=uint32(0);n<in.GetCount();n++ {
  if err:=send(wrapperspb.String(fmt.Sprintf("%s:%d",in.GetText(),n)));err!=nil{return err}
 }
 return nil
}
func TestOpaqueGeneratedSDK(t *testing.T) {
 ctx,stop:=context.WithTimeout(context.Background(),5*time.Second);defer stop()
 s,err:=rpc.NewServer(rpc.ServerConfig{});if err!=nil{t.Fatal(err)}
 defer s.Close()
 impl:=&implementation{canceled:make(chan struct{})}
 if err:=pb.RegisterEchoServer(s,impl);err!=nil{t.Fatal(err)}
 l,err:=net.Listen("tcp","127.0.0.1:0");if err!=nil{t.Fatal(err)}
 done:=make(chan error,1);go func(){done<-s.Serve(l)}()
 defer func(){s.Close();if err:=<-done;err!=nil{t.Error(err)}}()
 c,err:=rpc.Dial(ctx,l.Addr().String(),rpc.ClientConfig{RequiredFeatures:rpc.FeatureProtobuf|rpc.FeatureServerStreaming});if err!=nil{t.Fatal(err)}
 defer c.Close()
 sdk:=pb.NewEchoClient(c)
 for _,text:=range []string{"hello opaque",""} {
  in:=pb.Request_builder{Text:proto.String(text)}.Build()
  out,err:=sdk.Call(ctx,in);if err!=nil||out.GetValue()!=text{t.Fatalf("call: %v %v",out,err)}
 }
 if _,err:=sdk.Call(ctx,nil);err==nil{t.Fatal("nil request accepted")}
 stream,err:=sdk.Watch(ctx,pb.Request_builder{Text:proto.String("chunk"),Count:proto.Uint32(3)}.Build())
 if err!=nil{t.Fatal(err)};defer stream.Close()
 for n:=0;n<3;n++ {v,e:=stream.Recv();if e!=nil||v.GetValue()!=fmt.Sprintf("chunk:%d",n){t.Fatalf("stream: %v %v",v,e)}}
 if _,err:=stream.Recv();err!=io.EOF{t.Fatal(err)}
 call,cancel:=context.WithCancel(ctx);defer cancel()
 canceled,err:=sdk.Watch(call,pb.Request_builder{}.Build());if err!=nil{t.Fatal(err)}
 defer canceled.Close()
 if _,err:=canceled.Recv();err!=nil{t.Fatal(err)}
 cancel()
 if _,err:=canceled.Recv();!errors.Is(err,context.Canceled){t.Fatalf("cancel: %v",err)}
 select{case <-impl.canceled:case <-ctx.Done():t.Fatal("remote cancel not observed")}

 _,laterErr:=sdk.Later(ctx,pb.Request_builder{}.Build())
 var status *rpc.Status
 if !errors.As(laterErr,&status)||status.Code!=rpc.NotFound{t.Fatalf("default method: %v",laterErr)}
 report,err:=s.DrainWithReport(ctx)
 if err!=nil||!report.Quiescent||report.TotalFaults.LostTerminals!=0{t.Fatalf("drain: %+v %v",report,err)}
 if c.MemoryStats().Receive.Used!=0 {t.Fatal(c.MemoryStats())}
}
