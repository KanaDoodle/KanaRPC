module example.com/protobuf-consumer

go 1.26.10

require (
	github.com/KanaDoodle/KanaRPC v0.0.0
	google.golang.org/protobuf v1.36.12
)

require (
	github.com/quic-go/quic-go v0.64.1 // indirect
	golang.org/x/crypto v0.58.0 // indirect
	golang.org/x/net v0.62.0 // indirect
	golang.org/x/sys v0.49.0 // indirect
)

replace github.com/KanaDoodle/KanaRPC => /Users/kana/Projects/KanaRPC
