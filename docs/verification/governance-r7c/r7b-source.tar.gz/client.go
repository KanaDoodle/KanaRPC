package kanarpc

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"math"
	"net"
	"sync"
	"time"

	"github.com/KanaDoodle/KanaRPC/internal/wire"
)

type ClientStats struct {
	Pending, InFlightBufferedChunks          int
	Started, Completed, Canceled, LateFrames uint64
}

// Client owns a single multiplexed byte-stream connection. There is no implicit
// reconnect, business retry, registry worker, or background heartbeat.
type Client struct {
	cfg     ClientConfig
	link    *link
	ctx     context.Context
	cancel  context.CancelFunc
	mu      sync.Mutex
	closed  bool
	failure error
	nextID  uint64
	pending map[uint64]*pending
	stats   ClientStats
	once    sync.Once
	wg      sync.WaitGroup
	single  bool
}

func Dial(ctx context.Context, address string, cfg ClientConfig) (*Client, error) {
	var err error
	if cfg, err = normalizeClient(cfg); err != nil {
		return nil, err
	}
	conn, err := (&net.Dialer{}).DialContext(ctx, "tcp", address)
	if err != nil {
		return nil, err
	}
	client, err := NewClient(conn, cfg)
	if err != nil {
		closeSocket(conn)
	}
	return client, err
}

// NewClient transfers conn ownership on success only. It also accepts a
// caller-authenticated TLS connection; TLS construction is not automated here.
func NewClient(conn net.Conn, cfg ClientConfig) (*Client, error) {
	return newRecordClient(conn, cfg, false)
}

func newRecordClient(conn recordChannel, cfg ClientConfig, single bool) (*Client, error) {
	if conn == nil {
		return nil, errors.New("kanarpc: nil connection")
	}
	var err error
	if cfg, err = normalizeClient(cfg); err != nil {
		return nil, err
	}
	ctx, cancel := context.WithCancel(context.Background())
	c := &Client{cfg: cfg, link: newLink(conn, cfg.IO), ctx: ctx, cancel: cancel, pending: make(map[uint64]*pending), single: single}
	c.wg.Add(1)
	go func() { defer c.wg.Done(); c.readLoop() }()
	return c, nil
}

func (c *Client) Stats() ClientStats {
	c.mu.Lock()
	defer c.mu.Unlock()
	stats := c.stats
	stats.Pending = len(c.pending)
	for _, p := range c.pending {
		p.mu.Lock()
		stats.InFlightBufferedChunks += len(p.queue)
		p.mu.Unlock()
	}
	return stats
}
func (c *Client) fail(err error) {
	c.once.Do(func() {
		c.mu.Lock()
		c.closed = true
		c.failure = err
		all := make([]*pending, 0, len(c.pending))
		for _, p := range c.pending {
			all = append(all, p)
		}
		c.mu.Unlock()
		c.cancel()
		closeSocket(c.link.conn)
		for _, p := range all {
			p.finish(err, true)
			p.retire()
		}
	})
}

// Close unblocks I/O, cancels local calls, and joins readers/cancel callbacks.
func (c *Client) Close() { c.fail(ErrClosed); c.wg.Wait() }

type pending struct {
	client        *Client
	id            uint64
	ctx           context.Context
	cancel        context.CancelFunc
	stop          func() bool
	callbackDone  sync.Once
	retired       sync.Once
	creditMu      sync.Mutex
	mu            sync.Mutex
	changed       chan struct{}
	queue         []json.RawMessage
	next          uint32
	window        uint32
	remoteEnded   bool
	openSent      bool
	done, discard bool
	err           error
}

func (p *pending) notifyLocked() { close(p.changed); p.changed = make(chan struct{}) }
func (p *pending) finish(err error, discard bool) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.done {
		return false
	}
	p.done, p.discard, p.err = true, discard, err
	if discard {
		p.queue = nil
	}
	p.notifyLocked()
	return true
}
func (p *pending) retire() {
	p.retired.Do(func() {
		if p.stop() {
			p.callbackDone.Do(p.client.wg.Done)
		}
		p.cancel()
		c := p.client
		c.mu.Lock()
		delete(c.pending, p.id)
		c.stats.Completed++
		c.mu.Unlock()
		if c.single {
			finishChannel(c.link.conn)
			c.cancel()
		}
	})
}
func (p *pending) localCancel() {
	defer p.callbackDone.Do(p.client.wg.Done)
	if p.finish(p.ctx.Err(), true) {
		c := p.client
		c.mu.Lock()
		c.stats.Canceled++
		c.mu.Unlock()
		ctx, cancel := context.WithTimeout(c.ctx, c.cfg.ControlTimeout)
		// Open owns the writer permit until its success is recorded. A canceled
		// call that never reached the wire must not emit a future-ID Cancel.
		var touched bool
		err := c.link.acquire(ctx)
		if err == nil {
			p.mu.Lock()
			sent := p.openSent
			p.mu.Unlock()
			if sent {
				touched, err = c.link.writeLocked(ctx, wire.Frame{Kind: wire.Cancel, ID: p.id})
			}
			c.link.release()
		}
		cancel()
		if err != nil && touched {
			c.fail(err)
		}
	}
	p.retire()
}

// Stream begins one server-streaming call. Caller cancellation is always sent
// on the wire. Call and Stream share the same request/terminal state machine.
func (c *Client) Stream(ctx context.Context, method string, request any) (*Stream, error) {
	return c.open(ctx, method, request, true)
}
func (c *Client) open(ctx context.Context, method string, request any, streaming bool) (*Stream, error) {
	if !validMethod(method) {
		return nil, &Status{Code: InvalidArgument, Message: "expected /service/method"}
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	callCtx, cancel := context.WithTimeout(ctx, c.cfg.Timeout)
	body, err := json.Marshal(request)
	if err != nil {
		cancel()
		return nil, err
	}
	if err = c.link.acquire(callCtx); err != nil {
		cancel()
		return nil, err
	}
	// ID allocation, registration and Open writing share the writer permit, so
	// Open IDs increase on the wire even when callers race to start requests.
	c.mu.Lock()
	if c.closed {
		c.mu.Unlock()
		c.link.release()
		cancel()
		return nil, ErrClosed
	}
	if len(c.pending) >= c.cfg.MaxInFlight {
		c.mu.Unlock()
		c.link.release()
		cancel()
		return nil, &Status{Code: ResourceExhausted, Message: "client in-flight limit"}
	}
	if c.nextID == math.MaxUint64 {
		c.mu.Unlock()
		c.link.release()
		cancel()
		return nil, ErrClosed
	}
	c.nextID++
	window := uint32(c.cfg.StreamWindow)
	if !streaming {
		window = 1
	}
	p := &pending{client: c, id: c.nextID, ctx: callCtx, cancel: cancel, window: window, next: 1, changed: make(chan struct{})}
	c.wg.Add(1)
	callbackReady := make(chan struct{})
	p.stop = context.AfterFunc(callCtx, func() { <-callbackReady; p.localCancel() })
	c.pending[p.id] = p
	c.stats.Started++
	close(callbackReady)
	c.mu.Unlock()
	deadline, _ := callCtx.Deadline()
	b, _ := json.Marshal(openRecord{Method: method, BudgetNanos: int64(time.Until(deadline)), Window: window, Stream: streaming, Request: body})
	if uint64(len(b)) > uint64(c.cfg.IO.MaxFrameBytes) {
		c.link.release()
		p.finish(&Status{Code: InvalidArgument, Message: "request exceeds frame limit"}, true)
		p.retire()
		return nil, &Status{Code: InvalidArgument, Message: "request exceeds frame limit"}
	}
	touched, err := c.link.writeLocked(callCtx, wire.Frame{Kind: wire.Open, ID: p.id, Payload: b})
	if err == nil {
		p.mu.Lock()
		p.openSent = true
		p.mu.Unlock()
	}
	c.link.release()
	if err != nil {
		c.mu.Lock()
		if c.failure != nil {
			err = c.failure
		}
		c.mu.Unlock()
		p.finish(err, true)
		p.mu.Lock()
		result, discard := p.err, p.discard
		p.mu.Unlock()
		p.retire()
		if touched {
			c.fail(err)
		}
		if !discard {
			return &Stream{pending: p}, nil
		}
		return nil, result
	}
	return &Stream{pending: p}, nil
}

func (c *Client) Call(ctx context.Context, method string, request, response any) error {
	stream, err := c.open(ctx, method, request, false)
	if err != nil {
		return err
	}
	defer stream.Close()
	if err = stream.Recv(response); err != nil {
		if err == io.EOF {
			return ErrProtocol
		}
		return err
	}
	_, err = stream.recv()
	if err == io.EOF {
		return nil
	}
	if err == nil {
		return ErrProtocol
	}
	return err
}

func (c *Client) readLoop() {
	for {
		f, err := c.link.read()
		if err != nil {
			c.fail(err)
			return
		}
		c.mu.Lock()
		p, next := c.pending[f.ID], c.nextID
		if p == nil && f.ID <= next {
			c.stats.LateFrames++
		}
		c.mu.Unlock()
		if f.Kind != wire.Data && f.Kind != wire.End || f.ID > next {
			c.fail(ErrProtocol)
			return
		}
		if p == nil {
			continue
		}
		if f.Kind == wire.Data {
			p.mu.Lock()
			valid := !p.remoteEnded && f.Number == p.next && len(p.queue) < int(p.window) && json.Valid(f.Payload)
			if valid && !p.done {
				p.next++
				p.queue = append(p.queue, f.Payload)
				p.notifyLocked()
			}
			canceled := p.done
			p.mu.Unlock()
			if !valid && !canceled {
				c.fail(ErrProtocol)
				return
			}
			continue
		}
		var end endRecord
		if json.Unmarshal(f.Payload, &end) != nil || !knownCode(end.Code) || len(end.Message) > 256 {
			c.fail(ErrProtocol)
			return
		}
		var receipt []byte
		if end.Receipt != "" {
			receipt, err = hex.DecodeString(end.Receipt)
			if err != nil || len(receipt) != 16 {
				c.fail(ErrProtocol)
				return
			}
		}
		p.mu.Lock()
		duplicate, canceled := p.remoteEnded, p.done
		p.remoteEnded = true
		p.mu.Unlock()
		if duplicate {
			c.fail(ErrProtocol)
			return
		}
		// Stop new credits, join any in-progress credit write, ACK the terminal,
		// then publish completion. A normal END never cancels a credit mid-write.
		p.creditMu.Lock()
		if len(receipt) != 0 && !canceled {
			ctx, cancel := context.WithTimeout(p.ctx, c.cfg.ControlTimeout)
			touched, e := c.link.send(ctx, wire.Frame{Kind: wire.Ack, ID: p.id, Payload: receipt})
			cancel()
			if e != nil {
				p.creditMu.Unlock()
				if touched {
					c.fail(e)
				} else {
					p.finish(e, true)
					p.retire()
				}
				continue
			}
		}
		if c.single {
			if channel, ok := c.link.conn.(interface{ AwaitEnd(context.Context) error }); ok {
				budget, stop := context.WithTimeout(p.ctx, c.cfg.ControlTimeout)
				e := channel.AwaitEnd(budget)
				stop()
				if e != nil {
					p.creditMu.Unlock()
					c.fail(e)
					continue
				}
			}
		}
		var result error
		if end.Code != OK {
			result = &Status{Code: end.Code, Message: end.Message}
		}
		// Seal the native FIN before publishing completion. Close may race the
		// caller's return and must not turn a normal exchange into a reset.
		if c.single {
			finishChannel(c.link.conn)
		}
		p.finish(result, false)
		p.retire()
		p.creditMu.Unlock()
	}
}

type Stream struct {
	pending *pending
	recvMu  sync.Mutex
}

// Recv drains ordered chunks before a remote terminal error/EOF. Local
// cancellation discards buffered chunks. Concurrent Recv calls are serialized.
func (s *Stream) Recv(response any) error {
	s.recvMu.Lock()
	defer s.recvMu.Unlock()
	body, err := s.recv()
	if err != nil {
		return err
	}
	if response == nil {
		return nil
	}
	if err := json.Unmarshal(body, response); err != nil {
		_ = s.Close()
		return err
	}
	return nil
}
func (s *Stream) recv() (json.RawMessage, error) {
	p := s.pending
	for {
		p.mu.Lock()
		if p.discard {
			err := p.err
			p.mu.Unlock()
			return nil, err
		}
		if len(p.queue) > 0 {
			body := p.queue[0]
			p.queue[0] = nil
			p.queue = p.queue[1:]
			p.mu.Unlock()
			p.creditMu.Lock()
			p.mu.Lock()
			ended, discard, result := p.remoteEnded, p.discard, p.err
			p.mu.Unlock()
			if !ended && !discard {
				c := p.client
				touched, e := c.link.send(p.ctx, wire.Frame{Kind: wire.Credit, ID: p.id, Number: 1})
				if e != nil {
					p.mu.Lock()
					ended, discard, result = p.remoteEnded, p.discard, p.err
					p.mu.Unlock()
					if touched {
						c.fail(e)
					}
					if !ended || discard {
						p.creditMu.Unlock()
						if result != nil {
							return nil, result
						}
						return nil, e
					}
				}
			}
			p.creditMu.Unlock()
			p.mu.Lock()
			discard, result = p.discard, p.err
			p.mu.Unlock()
			if discard {
				return nil, result
			}
			return body, nil
		}
		if p.done {
			err := p.err
			p.mu.Unlock()
			if err == nil {
				err = io.EOF
			}
			return nil, err
		}
		changed := p.changed
		p.mu.Unlock()
		<-changed
	}
}
func (s *Stream) Close() error {
	p := s.pending
	p.mu.Lock()
	done := p.done
	p.mu.Unlock()
	if !done {
		p.cancel()
	}
	return nil
}
