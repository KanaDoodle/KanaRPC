package kanarpc

import (
	"context"
	"io"
	"testing"
	"time"
	"unsafe"
)

// Local accounting microbenchmarks deliberately exclude IO, encoding and QUIC.
// They isolate synchronization cost; they are not RPC capacity measurements.
func BenchmarkStopObservation(b *testing.B) {
	for _, mode := range []string{"acked_live", "acked_fin", "acked_deadline", "canceled", "transport"} {
		b.Run(mode, func(b *testing.B) {
			s := &Server{}
			b.ReportAllocs()
			b.ReportMetric(float64(unsafe.Sizeof(execution{})), "execution-bytes")
			b.RunParallel(func(pb *testing.PB) {
				parent, parentCancel := context.WithCancelCause(context.Background())
				defer parentCancel(nil)
				var ctx context.Context
				var stop context.CancelFunc
				if mode == "acked_deadline" {
					ctx, stop = context.WithDeadline(parent, time.Unix(1, 0))
					defer stop()
				} else {
					ctx = parent
				}
				r := &execution{peer: &serverConn{server: s, ctx: parent}, ctx: ctx, ack: make(chan struct{})}
				switch mode {
				case "acked_live", "acked_fin", "acked_deadline":
					close(r.ack)
				}
				switch mode {
				case "acked_fin", "transport":
					parentCancel(io.EOF)
				case "canceled":
					parentCancel(context.Canceled)
					r.cancelObserved = true
				}
				for pb.Next() {
					r.recordStop()
				}
			})
		})
	}
}
