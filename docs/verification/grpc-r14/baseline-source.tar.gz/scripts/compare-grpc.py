#!/usr/bin/env python3
"""Serialized paired two-process loopback comparison. Never hides failures."""
import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
TOOL = ROOT / "tools/grpc-compare"


def hashes():
    files = list(ROOT.glob("*.go")) + list((ROOT / "internal/wire").glob("*.go")) + list((ROOT / "internal/testcert").glob("*.go")) + list(TOOL.rglob("*.go")) + list(TOOL.rglob("*.proto"))
    files += [ROOT/"go.mod",ROOT/"go.sum",TOOL/"go.mod",TOOL/"go.sum",Path(__file__)]
    return {str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(set(files))}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--duration",type=float,default=2)
    parser.add_argument("--repeats",type=int,default=3)
    parser.add_argument("--race",action="store_true")
    parser.add_argument("--smoke",action="store_true")
    parser.add_argument("--focus",action="store_true",help="concurrency 16 only")
    parser.add_argument("--profile",action="store_true",help="diagnostic profiles, never performance evidence")
    args=parser.parse_args()
    if args.duration<=0 or args.repeats<1:parser.error("positive duration and repetitions required")
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
    env=dict(os.environ,GOWORK="off",GOMAXPROCS="4",GOTOOLCHAIN="go1.27.3")
    before=hashes();binary=output/"compare"
    build=["go","build","-mod=readonly","-o",str(binary)]
    if args.race:build.append("-race")
    build.append(".")
    with (output/"build.txt").open("wb") as log:subprocess.run(build,cwd=TOOL,env=env,stdout=log,stderr=log,check=True)
    metadata={"scope":"separate processes, serial closed-loop loopback; one persistent connection; no compression, discovery or governance; configured retries disabled, grpc transparent transport retries unchanged; per-RPC deadline 2s, limits 128, 64 warmups; not production/WAN/inference performance","args":vars(args)|{"output":str(output)},"source_sha256":before,"go":subprocess.check_output(["go","version"],cwd=TOOL,env=env,text=True).strip(),"modules":subprocess.check_output(["go","list","-m","all"],cwd=TOOL,env=env,text=True),"GOMAXPROCS":4,"binary_sha256":hashlib.sha256(binary.read_bytes()).hexdigest()}
    (output/"manifest.json").write_text(json.dumps(metadata,indent=2)+"\n")
    results=[];cases=[(t,size,c,chunks) for t in ["tcp","tls"] for size,chunks in [(64,1),(4096,1),(1024,8)] for c in ([1] if args.smoke else [1,16])]
    random.Random(20261101).shuffle(cases)
    if args.focus:cases=[c for c in cases if c[2]==16]
    try:
        for rep in range(args.repeats):
            for index,(transport,size,concurrency,chunks) in enumerate(cases):
                for engine in (["kana","grpc"] if (rep+index)%2==0 else ["grpc","kana"]):
                    name=f"r{rep}_{transport}_b{size}_c{concurrency}_n{chunks}_{engine}";folder=output/name;folder.mkdir();ready=folder/"ready.json";serverout=folder/"server.json"
                    options=["-engine",engine,"-transport",transport,"-ready",str(ready)]
                    with (folder/"server.stderr").open("wb") as stderr:
                        server_env=dict(env)
                        client_env=dict(env)
                        if args.profile:
                            server_env['KANARPC_COMPARE_PROFILE']=str(folder/'server')
                            client_env['KANARPC_COMPARE_PROFILE']=str(folder/'client')
                        server=subprocess.Popen([str(binary),"-mode","server",*options,"-out",str(serverout)],env=server_env,stdout=stderr,stderr=stderr)
                        owned=server.pid
                        try:
                            until=time.monotonic()+10
                            while not ready.exists():
                                if server.poll() is not None:raise RuntimeError(f"server exited: {name}")
                                if time.monotonic()>until:raise TimeoutError(name)
                                time.sleep(.01)
                            with (folder/"client.stderr").open("wb") as log:
                                client=subprocess.run([str(binary),"-mode","client",*options,"-out",str(folder/"client.json"),"-size",str(size),"-workers",str(concurrency),"-chunks",str(chunks),"-duration",str(args.duration)+"s"],env=client_env,stdout=log,stderr=log,timeout=args.duration+30)
                            if client.returncode:raise RuntimeError(f"client failed: {name}")
                            row=json.loads((folder/"client.json").read_text());row["run"]=name
                            results.append({k:v for k,v in row.items() if k!="offers"})
                            with gzip.open(folder/"client.json.gz","wt") as compressed:json.dump(row,compressed)
                            (folder/"client.json").unlink()
                            info=json.loads(ready.read_text())
                            with urllib.request.urlopen(urllib.request.Request(info["Admin"]+"/stop",data=b""),timeout=5) as response:response.read()
                            server.wait(timeout=8)
                            if server.returncode or json.loads(serverout.read_text())["Active"]!=0:raise RuntimeError(f"server did not settle: {name}")
                            if engine=="kana":
                                report=json.loads((folder/"server.json.drain.json").read_text())
                                if not report["Quiescent"] or any(report["TotalFaults"].values()):raise RuntimeError(f"delivery/drain failure: {name}")
                        finally:
                            if server.poll() is None:server.terminate();server.wait(timeout=5)
                            (folder/"ownership.json").write_text(json.dumps({"owned_pid":owned,"reaped":server.poll() is not None})+"\n")
                    print(name,"ok",flush=True)
        if hashes()!=before:raise RuntimeError("source changed during measurement")
        (output/"result.json").write_text(json.dumps({"status":"PASS","runs":results},indent=2)+"\n")
    except BaseException as e:
        (output/"result.json").write_text(json.dumps({"status":"FAIL","failure":repr(e),"runs":results},indent=2)+"\n");raise


if __name__=="__main__":main()
