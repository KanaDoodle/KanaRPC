package kanarpc
import "testing"
func BenchmarkByteLeaseAccounting(b *testing.B) {b.Run("local",func(b *testing.B){budget:=&byteBudget{stats:ByteStats{Limit:1<<20}};b.ReportAllocs();b.RunParallel(func(pb *testing.PB){for pb.Next(){l,e:=budget.lease(24);if e!=nil {b.Fatal(e)};l.release()}})})}
