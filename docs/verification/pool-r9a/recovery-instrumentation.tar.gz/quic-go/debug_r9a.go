package quic
import("fmt";"sort")
func(c *Conn) DebugR9A() string {
 m:=c.streamsMap; im:=m.incomingBidiStreams;im.mutex.RLock();strs:=make([]*Stream,0,len(im.streams));for _,e:=range im.streams {strs=append(strs,e.stream)};next,max:=im.nextStreamToOpen,im.maxStream;im.mutex.RUnlock()
 groups:=map[string]int{};for _,st:=range strs {s,r:=st.sendStr,st.receiveStr;s.mutex.Lock();a:=fmt.Sprintf("send:finished=%v cancel=%v completed=%v reset=%v outstanding=%d fin=%v next=%v queuedReset=%v retrans=%d pending=%d",s.finishedWriting,s.cancellationFlagged,s.completed,s.resetErr!=nil,s.numOutstandingFrames,s.finSent,s.nextFrame!=nil,s.queuedResetStreamFrame!=nil,len(s.retransmissionQueue),len(s.dataForWriting));s.mutex.Unlock();r.mutex.Lock();a+=fmt.Sprintf(" receive:cancel=%v remote=%v completed=%v final=%d errorRead=%v",r.cancelledLocally,r.cancelledRemotely,r.completed,r.finalOffset,r.errorRead);r.mutex.Unlock();groups[a]++};keys:=[]string{};for k,n:=range groups {keys=append(keys,fmt.Sprintf("%d x %s",n,k))};sort.Strings(keys)
 om:=m.outgoingBidiStreams;om.mutex.Lock();count:=len(om.streams);om.mutex.Unlock();return fmt.Sprintf("incoming=%d next=%d max=%d outgoing=%d groups=%v",len(strs),next,max,count,keys)
}
