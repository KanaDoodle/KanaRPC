package kanarpc
func(c *QUICClient) DebugR9A() string {return c.conn.DebugR9A()}
func(s *Server) DebugR9A() []string {s.mu.Lock();defer s.mu.Unlock();var v []string;for p:=range s.nativeSessions {v=append(v,p.conn.DebugR9A())};return v}
