// protoc-gen-kanarpc generates typed KanaRPC clients and service registration.
package main

import (
	bindings "github.com/KanaDoodle/KanaRPC/internal/protogen"
	"google.golang.org/protobuf/compiler/protogen"
)

func main() { protogen.Options{}.Run(bindings.Generate) }
