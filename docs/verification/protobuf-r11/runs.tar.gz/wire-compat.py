import pathlib,subprocess,os,json,struct,socket
ROOT=pathlib.Path('/Users/kana/Projects/KanaRPC');OUT=pathlib.Path(__file__).parent/'wire-compat-final';OUT.mkdir()
env=dict(os.environ,GOWORK='off',GOTOOLCHAIN='go1.27.3')
base=OUT/'baseline';base.mkdir()
files=subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],cwd=ROOT,text=True).splitlines()
for f in files:
 if f in ('go.mod','go.sum') or (f.endswith('.go') and not f.endswith('_test.go') and ('/' not in f or f.startswith('internal/wire/'))):
  dst=base/f;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(subprocess.check_output(['git','show','HEAD:'+f],cwd=ROOT))
source=r'''package main
import("bufio";"context";"fmt";"io";"net";"os";"time";rpc "github.com/KanaDoodle/KanaRPC")
func must(e error){if e!=nil{panic(e)}}
func main(){ctx,cancel:=context.WithTimeout(context.Background(),10*time.Second);defer cancel()
 if os.Args[1]=="client" {c,e:=rpc.Dial(ctx,os.Args[2],rpc.ClientConfig{});must(e);defer c.Close();var n int;must(c.Call(ctx,"/echo/call",42,&n));if n!=42{panic(n)};s,e:=c.Stream(ctx,"/echo/watch",3);must(e);defer s.Close();for i:=0;i<3;i++{must(s.Recv(&n));if n!=i{panic(n)}};if e=s.Recv(&n);e!=io.EOF{panic(e)};fmt.Println("JSON unary/stream PASS");return}
 s,e:=rpc.NewServer(rpc.ServerConfig{});must(e);defer s.Close();must(rpc.RegisterUnary(s,"/echo/call",func(_ context.Context,n int)(int,error){return n,nil}));must(rpc.RegisterStream(s,"/echo/watch",func(_ context.Context,n int,send func(int)error)error{for i:=0;i<n;i++{if e:=send(i);e!=nil{return e}};return nil}));l,e:=net.Listen("tcp","127.0.0.1:0");must(e);done:=make(chan error,1);go func(){done<-s.Serve(l)}();fmt.Println(l.Addr());bufio.NewScanner(os.Stdin).Scan();r,e:=s.DrainWithReport(ctx);must(e);must(<-done);if !r.Quiescent||r.After.Admitted!=2||r.TotalFaults.LostTerminals!=0{panic(fmt.Sprintf("%+v",r))};fmt.Println("drain/admitted=2 PASS")}
'''
results={}
for name,repo in [('old',base),('new',ROOT)]:
 work=OUT/name;work.mkdir();(work/'main.go').write_text(source)
 (work/'go.mod').write_text('module example.com/wire-'+name+'\n\ngo 1.26.10\n\nrequire github.com/KanaDoodle/KanaRPC v0.0.0\nreplace github.com/KanaDoodle/KanaRPC => '+json.dumps(str(repo))+'\n')
 with (work/'build.txt').open('wb') as log:
  subprocess.run(['go','mod','tidy'],cwd=work,env=env,stdout=log,stderr=log,check=True)
  subprocess.run(['go','build','-o',str(OUT/(name+'-peer')),'.'],cwd=work,env=env,stdout=log,stderr=log,check=True)
for server,client in [('old','new'),('new','old')]:
 log=(OUT/(server+'-server.stderr')).open('wb');p=subprocess.Popen([str(OUT/(server+'-peer')),'server'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,env=env)
 try:
  address=p.stdout.readline().strip();out=subprocess.check_output([str(OUT/(client+'-peer')),'client',address],env=env,text=True,timeout=12)
  if server=='old':
   host,port=address.rsplit(':',1)
   with socket.create_connection((host,int(port)),timeout=2) as sock:
    meta=json.dumps(dict(method='/echo/call',budget_ns=1000000000,window=1,stream=False,codec='protobuf'),separators=(',',':')).encode();body=struct.pack('>I',len(meta))+meta+b'\x08\x2a'
    sock.sendall(struct.pack('>4sBBHQII',b'KNR2',2,8,0,1,len(body),0)+body)
    try:
     if sock.recv(1)!=b'':raise RuntimeError('legacy peer accepted encoded OPEN')
     close_kind='EOF'
    except ConnectionResetError:close_kind='TCP reset'
   out+='unknown Protobuf record rejected before handler ('+close_kind+') PASS\n'
  tail,_=p.communicate('\n',timeout=12)
  if p.returncode:raise RuntimeError('server failed')
  results[server+'-server_'+client+'-client']=out+tail
 finally:
  if p.poll() is None:p.terminate();p.wait(timeout=4)
  log.close()
(OUT/'result.json').write_text(json.dumps({'status':'PASS','baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'scope':'real loopback JSON wire compatibility and legacy rejection, no automatic fallback/replay','checks':results},indent=2)+'\n')
print(json.dumps(results))
